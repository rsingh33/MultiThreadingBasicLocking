//Name : Rahul Singh Ub email : rsingh33@buffalo.edu

package assignment;

public class CDLFine<T> extends CDLList<T> {

	CDLFine(T v) {
		super(v);

	}

	public Element head() {
		return this.head;

	}

	public Cursor reader(Element from) {

		Cursor newCursor = new Cursor(from);
		return newCursor;
	}

	public class Cursor extends CDLList<T>.Cursor {
		// private Element cursorPosition;

		public Cursor(Element from) {

			super(from);
			cursorPosition = from;

		}

		public Element Current() {
			synchronized (cursorPosition) {

				return this.cursorPosition;
			}

		}

		public void next() {
			synchronized (cursorPosition) {
				synchronized (cursorPosition.next) {
					this.cursorPosition = cursorPosition.next;

				}
			}
		}

		public void previous() {
			synchronized (cursorPosition.previous) {
				synchronized (cursorPosition) {
					this.cursorPosition = cursorPosition.previous;
				}
			}
		}

		public Writer writer() {
			Writer writerPosition = new Writer(cursorPosition);
			return writerPosition;

		}

	}

	public class Writer extends CDLList<T>.Writer {

		// Element writerPosition;

		Writer(Element from) {
			super(from);
			writerPosition = from;
		}

		public boolean insertBefore(T val) {

			while (true) {
				Element dummyElement = writerPosition.previous;
				synchronized (writerPosition.previous) {
					synchronized (writerPosition) {

						if (dummyElement == writerPosition.previous) {
							super.insertBefore(val);
							return true;
						} else {
							System.out.println("Previous element has changed");
						}
					}

				}
			}
		}

		public boolean insertAfter(T val) {
			synchronized (writerPosition) {
				synchronized (writerPosition.next) {

					super.insertAfter(val);

					return true;
				}
			}
		}

	}

}