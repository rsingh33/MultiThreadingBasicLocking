//Name : Rahul Singh Ub email : rsingh33@buffalo.edu

package assignment;

public class CDLCoarse<T> extends CDLList<T> {

	private Object mylock = new Object();

	public CDLCoarse(T v) {
		super(v);

	}

	public Element head() {
		return this.head;
	}

	public Cursor reader(Element from) {

		Cursor newCursor = new Cursor(from);
		return newCursor;
	}

	public class Cursor extends CDLList<T>.Cursor {

		private Element cursorPosition;

		public Cursor(Element from) {
			super(from);
			cursorPosition = from;

		}

		public Element current() {
			synchronized (mylock) {
				return this.cursorPosition;
			}
		}

		public void previous() {
			synchronized (mylock) {
				this.cursorPosition = this.cursorPosition.previous;
			}
		}

		public void next() {
			synchronized (mylock) {
				this.cursorPosition = this.cursorPosition.next;
			}
		}

		public CDLList<T>.Writer writer() {
			Writer writerPosition = new Writer(this.cursorPosition);
			return writerPosition;

		}

	}

	public class Writer extends CDLList<T>.Writer {

		Element writerPosition;

		public Writer(Element from) {
			super(from);
			writerPosition = from;
		}

		// Add before the current element.

		public boolean insertBefore(T val) {
			synchronized (mylock) {

				Element node2 = new Element();
				node2.value = val;
				Element prevElement = writerPosition.previous;
				prevElement.next = node2;
				node2.previous = prevElement;
				node2.next = writerPosition;
				writerPosition.previous = node2;

				return true;
			}
		}

		// Add after the current element.
		public boolean insertAfter(T val) {
			synchronized (mylock) {
				Element node2 = new Element();
				node2.value = val;
				writerPosition.next.previous = node2;
				node2.next = writerPosition.next;
				node2.previous = writerPosition;
				writerPosition.next = node2;

				return true;
			}
		}
	}

}
