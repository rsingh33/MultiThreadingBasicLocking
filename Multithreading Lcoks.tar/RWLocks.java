//Name : Rahul Singh Ub email : rsingh33@buffalo.edu

//References from Jenkov Tutorials




package assignment;

public class RWLocks {
	private int w=0;
	private int r=0;
	private int w_req=0;

	// Lock method for read operation
	public void lockRead() throws InterruptedException {
		synchronized (this) {
			while (w > 0 || w_req > 0) {
				wait();
			}
			r++;
		}
	}
	
	//// Lock method for write operation
	public void lockWrite() throws InterruptedException {
		synchronized (this) {
			w_req++;
			while (r > 0 || w > 0) {
				wait();
			}
			w_req--;
			w++;
		}
	}

	public void unlockRead() throws InterruptedException {
		synchronized (this) {
			r--;
			notifyAll();
		}
	}

	public void unlockWrite() throws InterruptedException {
		synchronized (this) {
			w--;
			notifyAll();
		}
	}
}