//Name : Rahul Singh Ub email : rsingh33@buffalo.edu

package assignment;

public class CDLListFineRW<T> extends CDLList<T> {

	CDLListFineRW(T v) {
		super(v);

	}

	public Element head() {
		return this.head;

	}

	public Cursor reader(Element from) {

		Cursor newCursor = new Cursor(from);
		return newCursor;
	}

	public class Cursor extends CDLList<T>.Cursor {
		// private Element cursorPosition;

		public Cursor(Element from) {

			super(from);
			cursorPosition = from;

		}

		public Element Current() {
			try {
				cursorPosition.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
				Element current = cursorPosition;
			try {
				cursorPosition.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			return current;
		}

		public void next() {
			try {
				cursorPosition.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			try {
				cursorPosition.next.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			this.cursorPosition = cursorPosition.next;
			try {
				cursorPosition.next.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			try {
				cursorPosition.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}


		}

		public void previous() {
			try {
				cursorPosition.previous.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			try {
				cursorPosition.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			this.cursorPosition = cursorPosition.previous;
			
			try {
				cursorPosition.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			try {
				cursorPosition.previous.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

		}

		public Writer writer() {
			Writer writerPosition = new Writer(cursorPosition);
			return writerPosition;

		}

	}

	public class Writer extends CDLList<T>.Writer {

		// Element writerPosition;

		Writer(Element from) {
			super(from);
			writerPosition = from;
		}

		public boolean insertBefore(T val) {

			while (true) {
				Element dummyElement = writerPosition.previous;
				try {
					writerPosition.previous.lock.lockRead();
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				try {
					writerPosition.lock.lockRead();
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}

				if (dummyElement == writerPosition.previous) {
					super.insertBefore(val);

				} else {
					System.out.println("Previous element has changed");
				}
				try {
					writerPosition.lock.unlockRead();
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}
				try {
					writerPosition.previous.lock.unlockRead();
				} catch (InterruptedException ex) {
					ex.printStackTrace();
				}

				return true;

			}
		}

		public boolean insertAfter(T val) {
			try {
				writerPosition.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			try {
				writerPosition.next.lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			super.insertAfter(val);

			try {
				writerPosition.next.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			try {
				writerPosition.lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			return true;
		}
	}

}
