//Name : Rahul Singh Ub email : rsingh33@buffalo.edu
package assignment;

public class CDLCoarseRW<T> extends CDLList<T> {

	private RWLocks lock = new RWLocks();
	CDLCoarseRW(T v) {
		super(v);
	}

	public Element head() {
		return this.head;
	}

	public Cursor reader(Element from) {

		Cursor newCursor = new Cursor(from);
		return newCursor;
	}

	public class Cursor extends CDLList<T>.Cursor {

		private Element cursorPosition;

		public Cursor(Element from) {
			super(from);
			cursorPosition = from;

		}

		public Element current() {
			
			try {
				lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			Element elem = cursorPosition;
			
			try {
				lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
		
			return elem;

		}

		public void previous() {
			try {
				lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

			this.cursorPosition = this.cursorPosition.previous;
			try {
				lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

		}

		public void next() {
			try {
				lock.lockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			this.cursorPosition = this.cursorPosition.next;
			try {
				lock.unlockRead();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}

		}

		public CDLList<T>.Writer writer() {
			Writer writerPosition = new Writer(this.cursorPosition);
			return writerPosition;
		}

	}

	public class Writer extends CDLList<T>.Writer {

		Element writerPosition;

		public Writer(Element from) {
			super(from);
			writerPosition = from;
		}

		// Add before the current element.

		public boolean insertBefore(T val) {
			try {
				lock.lockWrite();
				} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			super.insertBefore(val);
			
			try {
				lock.unlockWrite();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			return true;
		}

		// Add after the current element.
		public boolean insertAfter(T val) {
			try {
				lock.lockWrite();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			super.insertAfter(val);
			
			try {
				lock.unlockWrite();
			} catch (InterruptedException ex) {
				ex.printStackTrace();
			}
			return true;

		}
	}
}